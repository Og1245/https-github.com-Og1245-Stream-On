# Stream On Android starter

This is an Android Studio project for the first Stream On app prototype.

## Current prototype
- Dark, cinematic streaming-style interface
- Home/discovery layout, category chips and local search
- Android WebView shell
- Online permission prepared

## Important
This starter does not include Prime Video's catalogue or unauthorised streams. Real playback must be connected to authorised provider pages, public-domain titles, or licensed video feeds. The current catalogue cards are demo placeholders.

## Build an APK
1. Install Android Studio (with Android SDK Platform 35).
2. Open this folder in Android Studio.
3. Allow Gradle sync to finish.
4. Choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location, normally `app/build/outputs/apk/debug/app-debug.apk`.

Package: `com.streamon.app`
Minimum Android: 6.0 (API 23)
